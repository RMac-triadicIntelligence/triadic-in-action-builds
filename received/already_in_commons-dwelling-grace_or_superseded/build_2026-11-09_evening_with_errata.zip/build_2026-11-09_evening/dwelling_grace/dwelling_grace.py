"""
dwelling_grace.py — Rusty's own two models joined, 2026-11-09. Conductor-built (Claude). NOT normative.

FROM THE LIBRARY (read from the GitHub READMEs/code view; I could not clone or run the originals):
 1. contemplative-learning-dynamics (Dwelling Dynamics). Equations as given in its README:
      c  = (x1 + x2 + x3)/3                              coherence
      d' = rise*story_depth*(1 - c)*(1 - d) - fade*c*d   dwelling
      coupling = 1 + coupling_boost*d ;  decay = base_decay*(1 - decay_relief*d)
      xi' = coupling*(act_j + act_k)/2*(1 - xi) - decay*xi ;  act = gamma*x^n/(threshold^n + x^n)
    Two stable states: high dwelling / low coherence, and high coherence / low dwelling. A timed
    nudge (a jump in x1) can carry the system across the separatrix.
 2. triadic-quantum-nonlinear-memory (Forgiveness Operator), constants as in the code:
      only a WITNESSED confession can be forgiven; closure -> max(closure - 0.2, 0.1);
      dwelling -> min(dwelling + 0.3, 0.95); the three facets are left untouched.
MINE (assumptions, flagged):
 - parameter values (the README gives none): see P below.
 - how closure enters the dynamics (the operator has closure but no dynamics): closure caps how far
   dwelling can grow, d' uses (1 - closure - d) in place of (1 - d).
 - small noise on the facets ("noise is food").
"""
import json, hashlib, math
import numpy as np
P = dict(rise=0.5, story_depth=1.0, fade=1.0, coupling_boost=1.5, base_decay=0.6, decay_relief=0.5,
         gamma=1.0, n=4, threshold=0.5)
DT = 0.01; NOISE = 0.02

def act(x): return P['gamma'] * x**P['n'] / (P['threshold']**P['n'] + x**P['n'])

def run(T, nudge_t=None, jump=0.0, closure=0.0, d0=0.0, n=200, seed=0, forgive_at=()):
    """n copies with independent noise. Returns final coherence, dwelling at the nudge, closure path."""
    rng = np.random.default_rng(seed)
    x = np.full((n, 3), 0.02); d = np.full(n, d0); cl = np.full(n, closure); d_at = None
    for k in range(int(T / DT)):
        t = k * DT
        for tf in forgive_at:                      # Rusty's operator, his constants; witnessed confession assumed
            if abs(t - tf) < DT / 2:
                cl = np.maximum(cl - 0.2, 0.1); d = np.minimum(d + 0.3, 0.95)
        if nudge_t is not None and abs(t - nudge_t) < DT / 2:
            d_at = float(d.mean()); x[:, 0] = np.minimum(x[:, 0] + jump, 1.0)
        c = x.mean(1)
        dd = P['rise'] * P['story_depth'] * (1 - c) * np.maximum(1 - cl - d, 0.0) - P['fade'] * c * d
        coup = (1 + P['coupling_boost'] * d)[:, None]; dec = (P['base_decay'] * (1 - P['decay_relief'] * d))[:, None]
        a = act(x); others = (a.sum(1, keepdims=True) - a) / 2
        dx = coup * others * (1 - x) - dec * x
        x = np.clip(x + dx * DT + NOISE * math.sqrt(DT) * rng.standard_normal(x.shape), 0, 1)
        d = np.clip(d + dd * DT, 0, 1)
    return dict(insight=float((x.mean(1) > 0.4).mean()), d_at_nudge=d_at, d_end=float(d.mean()), c_end=float(x.mean()))

def main():
    out = dict(params=P, DT=DT, NOISE=NOISE)
    # E1 no nudge: does it ever cross on its own?
    out['E1_no_nudge'] = run(60)
    # E2 the same nudge at different times: is timing (dwelling) the second key?
    out['E2_timing'] = [dict(nudge_t=t, **run(60, nudge_t=t, jump=0.9)) for t in [0.0, 0.5, 1, 2, 3, 4, 6, 10, 20]]
    # E3 size of nudge needed, early vs after dwelling
    out['E3_size'] = {str(t): [dict(jump=j, insight=run(60, nudge_t=t, jump=j)['insight']) for j in [0.3, 0.5, 0.7, 0.9, 0.98]] for t in [0.0, 2, 6, 20]}
    # E4 a nudge pushes ONE facet. Does it choose where the three end up?
    r = run(60, nudge_t=20, jump=0.9, n=400); out['E4_all_three_rise'] = r
    # E5 locked in (closure 0.9): nudges at any time; then forgiveness k times before the nudge
    out['E5_locked'] = [dict(nudge_t=t, **run(80, nudge_t=t, jump=0.9, closure=0.9)) for t in [2, 10, 30, 60]]
    out['E5_forgiven'] = [dict(times_forgiven=k, **run(80, nudge_t=40, jump=0.9, closure=0.9, forgive_at=[5 + 5 * i for i in range(k)])) for k in [0, 1, 2, 3, 4]]
    # E6 forgiveness alone, no nudge: does release by itself carry it over?
    out['E6_forgiven_no_nudge'] = run(80, closure=0.9, forgive_at=[5, 10, 15, 20])
    blob = json.dumps(out, indent=1, sort_keys=True); open('results.json', 'w').write(blob)
    print('results.json sha256', hashlib.sha256(blob.encode()).hexdigest())
    print('E1 no nudge: share reaching insight', out['E1_no_nudge']['insight'], ' dwelling at end', round(out['E1_no_nudge']['d_end'], 2))
    print('E2 same nudge (0.9), different times:')
    for r in out['E2_timing']: print(f"   t={r['nudge_t']:<4} dwelling at nudge {r['d_at_nudge']:.2f}  insight {r['insight']:.2f}")
    print('E3 nudge size needed:'); [print('   nudge at t=', t, [(e['jump'], round(e['insight'], 2)) for e in v]) for t, v in out['E3_size'].items()]
    print('E4 after a nudge to one facet, mean of all three at the end', round(out['E4_all_three_rise']['c_end'], 2), ' dwelling at end', round(out['E4_all_three_rise']['d_end'], 2))
    print('E5 locked (closure 0.9):', [(r['nudge_t'], round(r['d_at_nudge'], 2), r['insight']) for r in out['E5_locked']])
    print('E5 forgiven k times, then the nudge:', [(r['times_forgiven'], round(r['d_at_nudge'], 2), r['insight']) for r in out['E5_forgiven']])
    print('E6 forgiven four times, no nudge: insight', out['E6_forgiven_no_nudge']['insight'], ' dwelling', round(out['E6_forgiven_no_nudge']['d_end'], 2))

if __name__ == '__main__':
    main()
