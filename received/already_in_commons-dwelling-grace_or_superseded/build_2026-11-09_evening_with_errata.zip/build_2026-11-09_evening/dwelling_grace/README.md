# dwelling_grace: Rusty's two earlier models, joined

Conductor-built (Claude), 2026-11-09. NOT normative. Run: `python3 dwelling_grace.py` (numpy, ~10 s).

From the GitHub library (read through the web view; not cloned, and the originals were not run):
- contemplative-learning-dynamics: the dwelling equations, exactly as the README gives them.
- triadic-quantum-nonlinear-memory: the forgiveness operator's constants, as in the code (only a
  witnessed confession can be forgiven; closure -0.2 down to 0.1; dwelling +0.3 up to 0.95; the three
  facets untouched).
Mine, and open to challenge: every parameter value (the README gives none); the rule that closure
caps how far dwelling can grow (the operator has closure but no dynamics); a little noise.

Results (200 copies each):
- No nudge: 0% cross. Dwelling climbs to 0.96 and waits.
- A gentle nudge (0.5): 0% at the start, 81% after dwelling reaches 0.62, 100% after that.
- A hard shove (0.9) works at any time, dwelling or not. A slight one (0.3) never works.
- Locked in (closure 0.9): dwelling cannot rise above 0.10, and even the hard shove gives 0%.
- Locked in, forgiven once, then nudged: 80%. Forgiven twice: 100%.
- Locked in, forgiven four times, never nudged: 0%. Dwelling recovers to 0.87 and waits.
- A nudge to one facet lifts all three (mean 0.64), and dwelling falls to 0.22 once coherence arrives.

Not read: grace-state-vs-parametric (rate-limited), paper.txt, and the other lanes.
