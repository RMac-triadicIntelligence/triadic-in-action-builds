# Written 2026-11-09 18:2x CT, before commons.py was run for the first time

Predictions I am committing to:
- PA. Conservation: total fill held always equals total rain fallen. No organism originates any.
- PB. Riches: with an open hand (grip 0), more fill means more crossing. With a tight grip, more fill
  means LESS crossing past some point.
- PC. A child with the best possible inherited ground but no grace does not cross. Ground is
  inherited; the crossing is not.
- PD. Hoards return: organisms that never give hold a growing share while alive, and it comes back
  into circulation when they die.

Questions I do not know the answer to (no prediction):
- Q1. After the rain stops for good, does a society keep crossing, generation after generation,
  on the grace it already has? Or does it run out?
- Q2. Does lineage ground make a difference through a long silence (ground on vs empty)?
- Q3. With symmetric habit (giving loosens grip, refusing tightens it by the same rule), what does a
  society that starts in the middle become?
- Q4. What does a 20% minority that never gives do to everyone else?
