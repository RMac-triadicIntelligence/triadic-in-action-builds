"""
commons.py — "received, not taken": a free-hand society model built after the 2026-11-09 evening
reading of Mark 10:17-31 and Luke 12:16-21, 48. Conductor-built (Claude). NOT normative.

One sentence drives every rule here: what an organism has, it received.

World: N organisms on a ring; each lives one lifetime, then a child takes its place.
Landscape (never changed by anything): V(x) = H (x^2 - 1)^2. x = -1 "holding as mine",
x = +1 "holding as entrusted". Crossing the separatrix at x = 0 is the turning.

Each organism has
  x      where it stands
  L      fill: grace it is holding. Sources: rain from outside (the same for everyone), gifts
         passed on by others, estates of the dead. It can never make any itself.
  g      grip, in (0,1): how far it trusts in what it holds. This is its personal topography
         in one number. Only its own acts change it.
Rules
  lift     below its water line (V(x) < L, own side) the landscape does not hold it; above the
           line the landscape acts unchanged. (Reading A of grace_toy: the lift is real.)
  cling    it pulls itself back toward "mine" with force g*K*min(L, 4H): the tighter the grip
           and the more it holds, the harder the pull. Its own doing, not the landscape's.
  the call now and then a neighbour in need asks for half of what it holds. It gives with
           probability 1-g. Giving loosens its grip (g -> g(1-A)); refusing tightens it
           (g -> g + A(1-g)). The rule is symmetric: on average a call changes nothing.
  crossing once past x = 0.5 it has turned. From then on it keeps nothing: whatever reaches it,
           it passes straight on to its neighbours. Crossing does not use grace up.
  ground   at its crossing the family's lineage ground gains one bounded slice: how much its
           grip changed between birth and crossing. A child is born at x = -1 with nothing,
           and with grip G0 - RHO*tanh(ground): the terrain it starts on is shaped by what
           happened before it. It inherits no fill, no position and no crossing.
  death    its estate goes to its neighbours ("then whose shall those things be", Luke 12:20).
Arms: ground on / empty / shuffled (slices land on random families); rain for ever or stopping;
a minority pinned at "never gives" (an organism built to maximise what it holds).
"""
import json, math, hashlib
import numpy as np

H = 1.0; DT = 0.01; SIGMA = 0.35; K = 1.5
RAIN = 0.04; LIFE = 60.0; CALL = 0.2; Q = 0.5; A = 0.2
G0 = 0.5; RHO = 0.3; GMIN = 0.05; GMAX = 0.99; N = 240; UNIT = 0.1

V = lambda x: H * (x * x - 1.0) ** 2
dV = lambda x: 4.0 * H * x * (x * x - 1.0)


def move(x, L, g, rng):
    in_fill = (x < 0) & (V(x) < L)
    F = np.where(in_fill, 0.0, -dV(x))
    cling = np.where(x < 0, -g * K * np.minimum(L, 4 * H), 0.0)
    return np.clip(x + (F + cling) * DT + SIGMA * math.sqrt(DT) * rng.standard_normal(x.shape), -3, 3)


def society(seed, gens=12, silence_after=None, ground='on', pinned_frac=0.0, g0=G0, B=0.0, n_seeds_turned=0, relay=True):
    rng = np.random.default_rng(seed)
    x = -np.ones(N); L = np.zeros(N)
    pinned = rng.uniform(size=N) < pinned_frac
    g = np.where(pinned, 1.0, g0); g_birth = g.copy()
    crossed = np.zeros(N, bool); age = rng.uniform(0, LIFE, N)
    J = np.zeros(N); J_at_birth = np.zeros(N); R = np.zeros(N)
    if n_seeds_turned: crossed[rng.choice(N, n_seeds_turned, replace=False)] = True
    rained = 0.0; idx = np.arange(N); left = (idx - 1) % N; right = (idx + 1) % N
    G = gens
    stat = dict(deaths=np.zeros(G), turned=np.zeros(G), g_birth=np.zeros(G), crossings=np.zeros(G),
                hoard_pinned=np.zeros(G), top10=np.zeros(G), gave=np.zeros(G), calls=np.zeros(G))
    pairs = []                                   # (ground at birth, turned?) for each death
    max_err = 0.0
    for k in range(int(gens * LIFE / DT)):
        t = k * DT; gen = min(int(t // LIFE), G - 1)
        if silence_after is None or t < silence_after * LIFE:
            L += RAIN * DT; rained += RAIN * DT * N
        # the turned keep nothing: pass on whatever has reached them
        Lc = np.where(crossed, L, 0.0) if relay else np.zeros(N); inflow = 0.5 * np.roll(Lc, 1) + 0.5 * np.roll(Lc, -1); L = L - Lc + inflow; R += inflow
        # the call
        called = (~crossed) & (L > 0) & (rng.uniform(size=N) < CALL * DT)
        if called.any():
            i = idx[called]; gives = (rng.uniform(size=i.size) < (1 - g[i])) & ~pinned[i]
            stat['calls'][gen] += i.size; stat['gave'][gen] += gives.sum()
            gi = i[gives]; amt = Q * L[gi]
            rec = np.where(L[left[gi]] <= L[right[gi]], left[gi], right[gi])
            L[gi] -= amt; np.add.at(L, rec, amt); np.add.at(R, rec, amt)
            g[gi] *= (1 - A)
            ri = i[~gives & ~pinned[i]]; g[ri] += A * (1 - g[ri])
        # recognition (added after run 1): a gift that came through another's open hand may be seen
        # as given. Per UNIT of such gifts, with probability 1-g, the grip loosens by the factor 1-B.
        if B > 0:
            trial = (R >= UNIT) & ~crossed & ~pinned
            if trial.any():
                ti = idx[trial]; R[ti] -= UNIT
                seen = ti[rng.uniform(size=ti.size) < (1 - g[ti])]
                g[seen] *= (1 - B)
        # its own motion
        live = ~crossed
        x[live] = move(x[live], L[live], g[live], rng)
        new = live & (x >= 0.5)
        if new.any():
            crossed |= new; stat['crossings'][gen] += new.sum()
            d = (g_birth - g)[new]
            if ground == 'on': J[new] += d
            elif ground == 'shuffled': np.add.at(J, rng.integers(0, N, d.size), d)
        # death and birth
        age += DT; dead = age >= LIFE
        if dead.any():
            di = idx[dead]
            stat['deaths'][gen] += di.size; stat['turned'][gen] += crossed[di].sum(); stat['g_birth'][gen] += g_birth[di].sum()
            if t > 3 * LIFE: pairs += list(zip(J_at_birth[di].tolist(), crossed[di].tolist()))
            est = L[di].copy(); L[di] = 0.0
            np.add.at(L, left[di], est / 2); np.add.at(L, right[di], est / 2)
            x[di] = -1.0; crossed[di] = False; age[di] = 0.0; R[di] = 0.0
            g[di] = np.where(pinned[di], 1.0, np.clip(g0 - RHO * np.tanh(J[di]), GMIN, GMAX))
            g_birth[di] = g[di]; J_at_birth[di] = J[di]
        if k % 200 == 0:
            max_err = max(max_err, abs(L.sum() - rained))
        if (k + 1) % int(LIFE / DT) == 0:
            tot = L.sum() or 1.0
            stat['hoard_pinned'][gen] = L[pinned].sum() / tot
            stat['top10'][gen] = np.sort(L)[-N // 10:].sum() / tot
    out = {k2: v.tolist() for k2, v in stat.items()}
    out['turned_frac'] = [round(a / b, 3) if b else None for a, b in zip(stat['turned'], stat['deaths'])]
    out['mean_g_birth'] = [round(a / b, 3) if b else None for a, b in zip(stat['g_birth'], stat['deaths'])]
    out['give_rate'] = [round(a / b, 3) if b else None for a, b in zip(stat['gave'], stat['calls'])]
    out['conservation_max_error'] = max_err; out['total_rain'] = rained
    if pairs:
        p = np.array(pairs, float)
        out['ground_vs_turning_corr'] = None if p[:, 0].std() == 0 else round(float(np.corrcoef(p[:, 0], p[:, 1])[0, 1]), 3)
    return out


def riches_sweep(seed=1, n=600, T=30.0):
    """PB: fixed fill, fixed grip, no rain, no calls. Share that turn within T."""
    rng = np.random.default_rng(seed); tab = {}
    for g in [0.0, 0.1, 0.25, 0.5, 1.0]:
        row = []
        for Lf in [0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]:
            x = -np.ones(n); done = np.zeros(n, bool); Lv = np.full(n, Lf * H); gv = np.full(n, g)
            for _ in range(int(T / DT)):
                live = ~done; x[live] = move(x[live], Lv[live], gv[live], rng); done |= x >= 0.5
            row.append(round(float(done.mean()), 3))
        tab[str(g)] = row
    return dict(fill_over_barrier=[0.0, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0], share_turned_by_grip=tab)


def orphan_test(seed=2, n=600):
    """PC: best possible inherited ground (grip GMIN), no grace at all, one lifetime."""
    rng = np.random.default_rng(seed); x = -np.ones(n); done = np.zeros(n, bool)
    for _ in range(int(LIFE / DT)):
        live = ~done; x[live] = move(x[live], np.zeros(live.sum()), np.full(live.sum(), GMIN), rng); done |= x >= 0.5
    return dict(n=n, turned=int(done.sum()))


def mean_tf(runs, key='turned_frac'):
    return np.nanmean(np.array([[v if v is not None else np.nan for v in r[key]] for r in runs], float), 0).round(2).tolist()


def main():
    out = dict(params=dict(H=H, DT=DT, SIGMA=SIGMA, K=K, RAIN=RAIN, LIFE=LIFE, CALL=CALL, Q=Q, A=A, G0=G0, RHO=RHO, GMIN=GMIN, N=N, UNIT=UNIT, B=0.05))
    seeds = (11, 12, 13); B = 0.05          # chosen AFTER the sweep: the middle of the range that works
    arms = {
        'rain, ground on': dict(), 'rain, ground empty': dict(ground='empty'), 'rain, ground shuffled': dict(ground='shuffled'),
        'rain stops after gen 3, ground on': dict(silence_after=3), 'rain stops after gen 3, ground empty': dict(silence_after=3, ground='empty'),
        'rain, the turned KEEP what reaches them': dict(relay=False),
        'rain, 20% never give': dict(pinned_frac=0.2), 'rain stops after gen 3, 20% never give': dict(pinned_frac=0.2, silence_after=3),
        'it never rained': dict(silence_after=0),
    }
    for name, kw in arms.items():
        r = [society(sd, B=B, **kw) for sd in seeds]; out[name] = r
        line = f'{name}\n  turned/gen    {mean_tf(r)}\n  grip at birth {mean_tf(r, "mean_g_birth")}\n  give rate     {mean_tf(r, "give_rate")}'
        line += f'\n  conservation error {max(s["conservation_max_error"] for s in r):.1e}   ground~turning corr {[s.get("ground_vs_turning_corr") for s in r]}'
        line += f'\n  top-10% share of all fill {mean_tf(r, "top10")}'
        if 'never give' in name: line += f'\n  never-givers share of all fill {mean_tf(r, "hoard_pinned")}'
        print(line)
    blob = json.dumps(out, indent=1, sort_keys=True); open('results.json', 'w').write(blob)
    print('results.json sha256', hashlib.sha256(blob.encode()).hexdigest())

if __name__ == '__main__':
    main()
