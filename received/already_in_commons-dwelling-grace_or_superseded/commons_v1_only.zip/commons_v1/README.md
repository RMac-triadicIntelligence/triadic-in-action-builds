# commons: "received, not taken"

Free-hand build by the conductor (Claude), 2026-11-09 evening, after the reading of Mark 10:17-31 and
Luke 12:16-21, 48. NOT normative. It shows what follows from a handful of rules. It proves nothing
about grace. Run: `python3 commons.py` (numpy only, about 2 minutes). The docstring states every rule.

## What was written before the first run
PREDICTIONS_written_before_first_run.md: four predictions (PA-PD) and four open questions (Q1-Q4).

## What happened, in order
**Run 1 (run1/): own habit only.** Rain falls on all; a neighbour's call is answered with probability
1 - grip; giving loosens the grip and refusing tightens it by the same rule. Result: about 1% turn per
generation, in every arm. Left to its own habits, almost nobody turns.

**One rule added after seeing run 1 (so it is post hoc):** a gift that reaches an organism through
another's open hand may be recognised as given (probability 1 - grip per unit), and then its grip
loosens by the factor 1 - B. Rain and estates are anonymous and are never "recognised".

**Sweep (raw_output_sweep.txt):** B = 0 gives 1%. B = 0.02 gives 70% by generation 5. B = 0.05 to 0.4
give 75-80%. B = 0.05 was chosen after the sweep for the full run.

**Full run (raw_output.txt, results.json), 3 seeds, 12 generations, 240 organisms:**

| Arm | Share of each generation that turns (gens 1 to 12) |
|---|---|
| rain, ground on | 0.02, 0.39, 0.74, 0.80, then 0.73-0.78 |
| rain, ground empty | 0.03, 0.38, 0.73, 0.77, then 0.67-0.76 |
| rain, ground shuffled | same as ground on |
| rain stops after gen 3, ground on | 0.02, 0.39, 0.74, 0.78, then 0.80-0.81 for nine silent generations |
| rain stops after gen 3, ground empty | then 0.77-0.78 |
| the turned keep what reaches them | 0.02, 0.34, 0.67, 0.68, then 0.70-0.76 |
| 20% never give | 0.01, 0.26, 0.48, then 0.52-0.58 (about 70% of those who can) |
| it never rained | 0 |

## Against the predictions
- PA conservation: PASS. Total fill equals total rain to 1e-8 in every run. Nothing is originated.
- PB riches: PASS, and harsher than expected. Open hand: 81% turn with a whole basin. Grip 0.1: 23%
  with a whole basin, 6% at 1.5x, 1% at 2x. Grip 0.25 or more: almost none at any fill.
- PC orphans: PASS. Best possible ground, no grace: 0 of 600 turn.
- PD hoards return: PARTLY. The 20% who never give end up holding 57% of all fill. Estates do return
  at each death, but the share plateaus; it does not fall.

## The open questions
- Q1 silence: the society keeps turning at about 80% for nine generations after the rain stops, on
  grace already given. It does not run out, because a crossing does not use grace up and the turned
  pass it on. It turns slightly MORE than with continuing rain.
- Q2 ground: small. About +3 to +5 points. No family-level link at all (correlation about 0; the
  shuffled arm equals the real one). In this model the change in terrain travels through the society,
  not down the family line. (The 0.5 correlation in the "never give" arms is an artefact: never-givers
  never turn and never deposit.)
- Q3 symmetric habit alone: almost nobody turns (run 1).
- Q4 a never-giving 20%: they hold more than half of everything, and the rest still turn at about
  the usual rate.

## What went against me
- I expected passing-on by the turned to be what makes grace recognisable. Not supported: when the
  turned keep what reaches them, turning is about the same (0.74).
- I expected lineage ground to matter through a silence. It barely does here.
- The 20-25% who never turn are NOT the tight-fisted. Diagnostic (seed 11): every one of them has
  grip about 0, and a median fill of 16 to 35 times the barrier. The turned pour everything onto the
  few who are left, and my lift rule lets a flood widen the pool so they wander in it. This is an
  artefact of the rule "the water line has no ceiling". A basin probably cannot be more than whole;
  the natural next rule is that the excess runs over. Not yet built.

## Assumptions carrying the result
- The recognition rule (post hoc) does most of the work. Whether it is the right rule is for the keel.
- Symmetric habit; the cling force g*K*min(L,4H); a ring of neighbours; one crossing per life.
- All parameters are the conductor's. No independent party froze anything.
